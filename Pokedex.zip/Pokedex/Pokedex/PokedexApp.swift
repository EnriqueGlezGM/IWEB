//
//  PokedexApp.swift
//  Pokedex
//
//  Created by Santiago Pavón Gómez on 31/07/2020.
//

import SwiftUI

@main
struct PokedexApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
