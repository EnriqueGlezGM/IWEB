//
//  LevelSelector.swift
//  Try2Smile
//
//  Created by Santiago Pavón Gómez on 04/08/2020.
//

import SwiftUI

struct ConfigSelector: View {
    
    @ObservedObject var partida: GameModel
    
    @Binding var showLevelSelector: Bool


    var body: some View {
        NavigationView  {
            Form {
                Section(header: Text("DIFICULTAD")) {
                    Picker("Nivel", selection: $partida.level) {
                        Text("Fácil").tag(GameLevel.easy)
                        Text("Normal").tag(GameLevel.normal)
                        Text("Difícil").tag(GameLevel.hard)
                    }
                }
                Section(header: Text("ABOUT")) {
                    HStack {
                        Text("Versión")
                        Spacer()
                        Text("0.0.0")
                    }
                }
            }
            .navigationBarTitle("Configuración")
            .navigationBarItems(trailing: Button(action: {
                showLevelSelector = false
            }, label: {
                Image(systemName: "multiply.circle")
            }))
            
            Text("Despliegue el menú deslizando desde el lateral.")
        }
    }
}

struct LevelSelector_Previews: PreviewProvider {
    static var previews: some View {
        ConfigSelector(partida: GameModel(),
                       showLevelSelector: .constant(true))
    }
}
