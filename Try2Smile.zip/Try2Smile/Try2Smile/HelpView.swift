//
//  HelpView.swift
//  Try2Smile
//
//  Created by Santiago Pavón Gómez on 04/08/2020.
//

import SwiftUI


struct HelpView: View {
    
    @Binding var showHelp: Bool
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Spacer()
                Button(action: {
                    showHelp = false
                }, label: {
                    Image(systemName: "multiply.circle")
                })
            }
            
            ScrollView {
                VStack(alignment: .leading) {
                    Text("Gana el último")
                        .font(.largeTitle)
                        .padding(.vertical)
                    
                    Text("Ayuda")
                        .font(.headline)
                    VStack(alignment: .leading) {
                        
                        Text("En este juego, el usuario y el teléfono compiten por ganar.")
                        Text("El juego consiste el reducir el valor de los dados hasta que todos tienen cero puntos.")
                        Text("En cada turno, el jugador solo puede modificar el valor de un dado.")
                        Text("Para cambiar un dado, pulse el dado rojo de la derecha que muestra el valor que se desea asignar.")
                        Text("Gana el jugador que mueve en el último turno, dejando todos los dados a cero.")
                    }
                    .padding()
                    
                    Text("Níveles")
                        .font(.headline)
                    VStack(alignment: .leading) {
                        
                        Text("Fácil: ")
                            .fontWeight(.bold) +
                            Text("el iPhone realiza tiradas aleatorias.")
                        Text("Normal: ")
                            .fontWeight(.bold) +
                            Text("el iPhone realiza tiradas aleatorias o óptimas con una probabilidad 50%.")
                        Text("Difícil: ")
                            .fontWeight(.bold) +
                            Text("el iPhone realiza tiradas óptimas.")
                    }
                    .padding()
                    
                    Text("Créditos")
                        .font(.headline)
                    VStack(alignment: .leading) {
                        
                        Text("SPG - IWEB 2020-2021 - UPM")
                    }
                    .padding()
                    
                    Spacer()
                }
            }
        }
        .padding()
    }
}

struct HelpView_Previews: PreviewProvider {
    static var previews: some View {
        HelpView(showHelp: .constant(true))
    }
}
