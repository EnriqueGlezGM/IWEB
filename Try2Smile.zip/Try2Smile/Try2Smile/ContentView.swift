//
//  ContentView.swift
//  Try2Smile
//
//  Created by Santiago Pavón Gómez on 03/08/2020.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var partida: GameModel = GameModel()
    
    @Environment(\.verticalSizeClass) var verticalSizeClass
    
    var body: some View {
        VStack {
            BarItems(partida: partida)
            Text("Gana el último")
                .font(.largeTitle)
                .fontWeight(.bold)
            Group { // Para que la transicion aplique a todas las subviews
                if partida.finished {
                    Spacer()
                    GameOverView(partida: partida, iAmTheWinner: partida.iAmTheWinner)
                    if verticalSizeClass != .compact {
                        FinishSmile(iAmTheWinner: partida.iAmTheWinner)
                    }
                    Spacer()
                } else {
                    DadosRows(partida: partida)
                    ActionView(miTurno: partida.myTurn)
                    if verticalSizeClass != .compact {
                        TurnoView(miTurno: partida.myTurn)
                    }
                    Spacer()
                }
            }
            .transition(AnyTransition.scale
                            .animation(Animation.easeInOut(duration: 0.6)
                                        .delay(0.3)))
            
            if verticalSizeClass != .compact {
                ScoresView(ganadas: partida.scoreWon,
                           perdidas: partida.scoreLost)
            }
        }
        .padding(.leading)
    }
}


struct DadosRows: View {
    
    @ObservedObject var partida: GameModel
    
    var body: some View {
        VStack(alignment: .leading) {
            Divider()
            ForEach(0..<partida.GAME_SIZE) { i in
                DadoRow(partida: partida,
                        row: i)
                    .animation(.easeInOut)
            }
            Divider()
        }
    }
}


struct DadoRow: View {
    
    @ObservedObject var partida: GameModel
    
    var row: Int
    
    var body: some View {
        HStack {
            Image("dado\(partida.rows[row])")
                .resizable()
                .hueRotation(Angle(degrees: partida.rows[row] > 0 ? 0 : 100))
                .frame(width: 40, height: 40)
                .padding(.horizontal)
            
            if partida.rows[row] > 0 {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        let range: ClosedRange<Int> = {0...partida.rows[row]-1}()
                        ForEach(range.reversed(), id: \.self) {i in
                            Button
                            {
                                partida.userPlay(value: i, row: row)
                            } label: {
                                Image("dado\(i)")
                                    .renderingMode(.original)
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .hueRotation(Angle(degrees: partida.rows[row] > 0 ? 220 : 100))
                                    .saturation(partida.myTurn ?? false ? 1 : 0)
                                    .opacity(partida.myTurn ?? false ? 1 : 0.5)
                            }
                            .disabled(!(partida.myTurn ?? false))
                        }
                    }
                }
            }
        }
    }
}


struct ScoresView: View {
    var ganadas: Int
    var perdidas: Int
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("Partidas ganadas: \(ganadas)")
                Text("Partidas perdidas: \(perdidas)")
            }
            .padding(.vertical)
            Spacer()
        }
    }
}


struct TurnoView: View {
    var miTurno: Bool?
    var body: some View {
        HStack {
            if let miTurno = miTurno {
                Text("Turno:")
                Text(miTurno ? "Jugador" : "iPhone")
                    .foregroundColor(miTurno ? .green : .orange)
                Spacer()
            }
        }
        .font(.largeTitle)
        .padding(.vertical)
    }
}

struct ActionView: View {
    var miTurno: Bool?
    var body: some View {
        HStack {
            if let miTurno = miTurno {
                if miTurno {
                    Text("Seleccione el valor a modificar")
                        .foregroundColor(.green)
                } else {
                    Text("iPhone pensando")
                        .foregroundColor(.orange)
                    ProgressView()
                }
                Spacer()
            }
        }
        .font(.body)
    }
}


struct GameOverView: View {
    
    @ObservedObject var partida: GameModel
    
    // Este parametro lo paso para que la transicion funcione bien.
    // Al tener este parametro en el constructor, se crea otra view, y no
    // se reutiliza nada de la anterior.
    let iAmTheWinner: Bool?
    
    var body: some View {
        VStack {
            Text("Juego Terminado")
                .font(.title3)
            if let iAmTheWinner = /*partida.*/iAmTheWinner {
                if iAmTheWinner {
                    Text("Has ganado")
                        .foregroundColor(.green)
                } else {
                    Text("Has perdido")
                        .foregroundColor(.red)
                }
            }
            
            Button {
                partida.start()
            } label: {
                Label("Jugar otra partida", systemImage: "arrow.triangle.2.circlepath")
            }
            .font(.body)
            .padding(7)
            .overlay(RoundedRectangle(cornerRadius: 10)
                        .stroke()
                        .foregroundColor(.accentColor))
            .padding(7)
        }
        .font(.largeTitle)
    }
}


struct FinishSmile: View {
    
    let iAmTheWinner: Bool?
    
    var body: some View {
        
        if let iAmTheWinner = iAmTheWinner {
            Image(iAmTheWinner ? "smile" : "unhappy")
                .resizable()
                .frame(width: 150, height: 150)
                .padding(.horizontal)
        } else {
            EmptyView()
        }
    }
}


struct BarItems: View {
    @ObservedObject var partida: GameModel
    
    @State var showHelp: Bool = false
    @State var showLevelSelector: Bool = false
    
    var body: some View {
        HStack {
            Spacer()
            
            if partida.finished {
                Button(action: {
                    partida.start()
                })  {
                    Image(systemName: "arrow.triangle.2.circlepath")
                }
            }
            
            Button(action: {
                showHelp = true
            }, label: {
                Image(systemName: "info.circle")
            })
            .sheet(isPresented: $showHelp, content: {
                HelpView(showHelp: $showHelp)
            })
            
            Button(action: {
                showLevelSelector = true
            }, label: {
                Image(systemName: "gearshape")
            })
            .sheet(isPresented: $showLevelSelector, content: {
                ConfigSelector(partida: partida, showLevelSelector: $showLevelSelector)
            })
        }
        .padding(.horizontal)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
                .previewLayout(.device)
            ContentView()
                .preferredColorScheme(.dark)
                .previewLayout(.device)
        }
    }
}
