//
//  Partidamodel.swift
//  Try2Smile
//
//  Created by Santiago Pavón Gómez on 03/08/2020.
//

import Foundation


enum GameLevel {
    case easy, normal, hard
}

class GameModel: ObservableObject {
    
    // Numero de filas/dados
    let GAME_SIZE = 4
    
    var level = GameLevel.hard
    
    // Los valores de los dados
    @Published var rows: [Int]!
    
    @Published var myTurn: Bool? {
        didSet {
            if let myTurn = myTurn,
               myTurn == false {
                self.computerPlay()
            }
        }
    }
    
    @Published var iAmTheWinner: Bool?
    @Published var finished: Bool = true

    @Published var scoreWon: Int = 0
    @Published var scoreLost: Int = 0
    
    init() {
        start()
    }
    
    /*
     * Acceder a los valores de la fila indicada.
     */
    subscript(row: Int) -> Int {
        get {
            rows[row]
        }
        set {
            rows[row] = newValue
        }
    }
    
    /*
     * Cargar valores aleatorios y empezar el juego.
     */
    func start() {
        rows = []
        for _ in 0..<GAME_SIZE {
            rows.append(Int.random(in: 1...9))
        }
        myTurn = true
        iAmTheWinner = nil
        finished = false
    }
    
    func computerPlay() {
        Timer.scheduledTimer(withTimeInterval: 2,
                             repeats: false) {_ in
            switch self.level {
            case .easy:
                self.doRandom()
            case .normal:
                if Bool.random() {
                    self.doRandom()
                } else {
                    self.doSmart()
                }
            case .hard:
                self.doSmart()
            }
            
            if self.rows.max() == 0 { // La partida ha terminado
                self.scoreLost += 1
                self.iAmTheWinner = false
                self.myTurn = nil
                Timer.scheduledTimer(withTimeInterval: 1,
                                     repeats: false) {_ in
                    self.finished = true
                }
            } else {
                self.myTurn = true
            }
        }
    }
    
    
    /*
     * Muevo yo, dejando "valor" en la fila "row".
     */
    func userPlay(value: Int, row: Int) {
        defer {
            if rows.max() == 0 { // La partida ha terminado
                scoreWon += 1
                iAmTheWinner = true
                myTurn = nil
                Timer.scheduledTimer(withTimeInterval: 1,
                                     repeats: false) {_ in
                    self.finished = true
                }
            } else {
                myTurn = false
            }
        }
        
        assert(row < GAME_SIZE)
        assert(value >= 0)
        assert(value < rows[row])
        
        self[row] = value
    }
    
    /*
     * Quita un numero aleatorio de una posicion aleatoria.
     */
    private func doRandom(){
        let offset =  Int.random(in: 0...GAME_SIZE)
        
        for i in 0..<GAME_SIZE {
            let row = (i + offset) % GAME_SIZE
            
            if rows[row] != 0 {
                rows[row] = Int.random(in: 0...rows[row]-1)
                return
            }
        }
    }
    
    
    /*
     * Se piensa la jugada e intenta quitar lo necesario para ganar.
     * Si no es capaz de quitar algo inteligente, quita algo aleatorio.
     */
    private func doSmart() {
        assert (!finished)
        
        let sum = binarySum()
        let pos = biggerBit1Position(n: sum)
        
        if pos == -1 {
            doRandom()
            return
        }
        
        let mask = 1 << pos
        
        for i in 0..<GAME_SIZE {
            if (rows[i] & mask) != 0 {
                rows[i] ^= sum
                return
            }
        }
        doRandom()
    }
    
    
    /*
     * Realiza la suma binaria de los valores de las filas sin acarreo.
     */
    private func binarySum() -> Int {
        rows.reduce(0, { res, valor in res ^ valor })
    }
    
    
    /*
     * Busca en rows un valor que tenga a 1 un determinado bit.
     * Ese bit debe ser el mismo que el bit de mayor peso de la suma binaria.
     * Devuelve la posicion en rows donde esta ese valor.
     * Si no existe, devuelve -1.
     */
    private func rowToDo() -> Int {
        let pos = biggerBit1Position(n: binarySum())
        if pos == -1 { return -1 }

        let mask = 1 << pos
        
        for i in 0..<GAME_SIZE {
            if (rows[i] & mask) != 0 {return i}
        }
        
        return -1
    }
    
    /*
     * Busca en la representacion binaria la posicion del 1 de mas peso contando desde la derecha
     * del numero dado.
     */
    private func biggerBit1Position(n: Int) -> Int {
        
        var pos = -1
        var n = n
        while n != 0 {
            n >>= 1
            pos += 1
        }
        return pos;
    }
}

