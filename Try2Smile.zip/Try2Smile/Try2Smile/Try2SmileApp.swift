//
//  Try2SmileApp.swift
//  Try2Smile
//
//  Created by Santiago Pavón Gómez on 03/08/2020.
//

import SwiftUI

@main
struct Try2SmileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
